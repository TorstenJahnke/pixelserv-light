/* Auto-generated from: examples/templates/zero.html */

#ifndef INCLUDE_TEMPLATES_ZERO_TEMPLATE_H
#define INCLUDE_TEMPLATES_ZERO_TEMPLATE_H

unsigned char zero_html[] = {

};
unsigned int zero_html_len = 0;

#endif /* INCLUDE_TEMPLATES_ZERO_TEMPLATE_H */
